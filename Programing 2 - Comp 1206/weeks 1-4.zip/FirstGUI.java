import java.awt.BorderLayout;

import javax.swing.*;



public class FirstGUI {

	public static void main(String[] args) {
		// THIS IS QUESTION 1
		MyFrame frame1 = new MyFrame();
		
		Q2Frame myQ2Frame = new Q2Frame();
		
		Q3Frame myQ3Frame = new Q3Frame();

		while (true){
			
		}

	}

}
